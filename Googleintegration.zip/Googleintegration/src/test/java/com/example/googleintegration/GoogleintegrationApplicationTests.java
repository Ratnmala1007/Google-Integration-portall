package com.example.googleintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoogleintegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
