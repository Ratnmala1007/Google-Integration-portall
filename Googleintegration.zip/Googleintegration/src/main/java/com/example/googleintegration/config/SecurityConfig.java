package com.example.googleintegration.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.example.googleintegration.security.CustomOidcUserService;

@Configuration
public class SecurityConfig {

	 @Bean
	    public RestTemplate restTemplate() {
	        return new RestTemplate();
	    }
	}
