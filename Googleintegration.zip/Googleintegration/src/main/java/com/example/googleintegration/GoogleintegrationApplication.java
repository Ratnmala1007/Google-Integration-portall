package com.example.googleintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleintegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleintegrationApplication.class, args);
		System.out.println("Run successfully");
	}

}
