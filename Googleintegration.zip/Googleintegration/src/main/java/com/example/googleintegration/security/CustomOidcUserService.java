package com.example.googleintegration.security;

import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;


import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Service;

@Service
public class CustomOidcUserService extends OidcUserService {

    @Override
    public OidcUser loadUser(OidcUserRequest userRequest) {
        // You can customize the user loading process here.
        OidcUser oidcUser = super.loadUser(userRequest);

        // You can process the user details here, e.g., storing or modifying claims.

        return oidcUser;
    }
}
