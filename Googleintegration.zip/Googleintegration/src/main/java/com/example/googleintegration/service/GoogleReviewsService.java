package com.example.googleintegration.service;
import org.springframework.http.HttpHeaders;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GoogleReviewsService {
    private final RestTemplate restTemplate;

    @Autowired
    public GoogleReviewsService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String fetchReviews(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange(
            "https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations/{locationId}/reviews",
            HttpMethod.GET, entity, String.class);

        return response.getBody();
    }
    public String respondToReview(String token, String reviewId, String response) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("response", response);

        HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(
            "https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations/{locationId}/reviews/{reviewId}/reply",
            HttpMethod.POST, entity, String.class);

        return responseEntity.getBody();
    }

}
