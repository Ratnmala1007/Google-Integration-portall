package com.example.googleintegration.controller;

import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reviews")
public class ReviewsController {

    @GetMapping
    public String getReviews(OAuth2AuthenticationToken authentication) {
        // Extract user information from the authentication object
        String userName = authentication.getPrincipal().getName();
        // Logic to fetch reviews

        return "Reviews for user: " + userName;
    }
}
